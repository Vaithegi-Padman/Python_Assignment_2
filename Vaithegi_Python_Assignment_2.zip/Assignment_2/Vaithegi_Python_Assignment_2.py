# List Creation
# Creating age list
age_list = [24,25,26,27,28]
print (age_list)
# Creating name list
name_list = ['Priya','Prem','Preeethi','Divya','Kiran']
print (name_list)
# a. Append "Yazhini" to name_list
name_list.append("Yazhini")
print ("After Append: ", name_list)
# b. Insert the element 30 at index 2 in age_list.
age_list.insert(2,30)
print ("After Insert: ", age_list)
# c. Remove the string "Yazhini" from name_list
name_list.remove("Yazhini")
print ("After Remove: ", name_list)
# d. Pop the last element from age_list.
age_list.pop()
print ("After Pop: ", age_list)
# e. Extend the age_list with additional ages [29, 30, 26].
age_list.extend([29,30,26])
print("After Extend: ", age_list)
# f. Sort age_list in descending order.
age_list.sort(reverse=True)
print("After Sort: ", age_list)
# g. Find Max age, Min age and sum of all ages from age_list.
# Max age
max_age = max(age_list)
# Min age
min_age = min(age_list)
# Sum of all age
total_age = sum(age_list)
print ("Maximum age: ", max_age)
print ("Minimum age: ", min_age)
print ("Sum of all age: ", total_age)
# a. Print the first element of name_list.
print ("First element: ", name_list[0])
# b. Print the last element of name_list.
print ("Last Element: ", name_list[-1])
# c. Print the elements from index 2 to index 4 in name_list. 
print ("Element from index 2 to 4: ", age_list[2:5])
# d. Print the elements of name_list in reverse order.
print ("Reverse Order: ", name_list[::-1])
# Dictionary
# a. Create a dictionary named student_marks that maps the names of five
student_mark = {"Priya":75,"Prem":88,"Preethi":65,"Divya":85,"Kiran":78}
print (student_mark)
# b. Access and print the mark of a specific student, of your choice.
print ("Priya's mark:", student_mark["Priya"])
# c. Add a new student "Janani" with a mark of 80 to the student_marks dictionary.
student_mark["Janani"] =80
print ("After Adding Student", student_mark)
# d. Update the mark of any one older student to 82.
student_mark["Preethi"] = 82
print ("Updated student Preethi's mark: ", student_mark["Preethi"])
# e. Print all keys, values, and key-value pairs
# keys()
print("All Keys:", student_mark.keys())
# values()
print("All Values:", student_mark.values())
# items()
print("All Key-Value Pairs:", student_mark.items())
# set()
# a. Create a set called my_set with following values:
my_set = {'a', 'e', 'i', 'o', 'u', 'a', 'a', 'i'}
print(my_set)
# b. Attempt to change the value of my_set[4] = 's'. 
# my_set[4] = 's'
# c. Create two sets:
# set1:
set1 = {1, 3, 5, 7, 9}
# set2:
set2 = {2, 3, 5, 8, 10}
print ("Set 1:", set1)
print ("Set 2:", set2)
# d. Compute and print the union and intersection of set1 and set2.
# Union:
union_set = set1.union(set2)
# Intersection
intersection_set = set1.intersection(set2)
print("Union:", union_set)
print("Intersection:", intersection_set)
# Prompt user to enter a score
score = float(input("Enter your score (0 to 10): "))
# Check whether the score is within the valid range
if score < 0 or score > 10:
    print("Invalid Score! Please enter score between 0 & 10.")
# Performance category
elif score > 7:
    print ("Above Average: Excellent performance! Keep up the great work.")
elif score >=4 and score <= 7:
    print("Average: Good effort! Keep practicing, need improvement.")    
else:
    print("Below Average: Need to improve your performance. Consistent practice will lead to better results.")
